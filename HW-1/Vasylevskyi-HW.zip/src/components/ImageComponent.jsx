function ImageComponent() {
    return <img src="https://placehold.co/150x150" alt="imageComponent" />

}

export default ImageComponent