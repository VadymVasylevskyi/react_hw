function ParagraphsComponent() {
    return <div>
        <h2>Some title</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt, tempora! Beatae odit ex unde quod!</p>
        <br />
        <h2>Some title</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Explicabo ipsum reiciendis non maiores quaerat eligendi illum expedita enim! Temporibus, dolore!</p>

    </div>
}

export default ParagraphsComponent